module.exports = {
  shopping: require("./shopping"),
  appEvents: require("./app-events"),
};
